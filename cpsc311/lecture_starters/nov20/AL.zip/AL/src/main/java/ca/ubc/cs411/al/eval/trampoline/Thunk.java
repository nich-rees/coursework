package ca.ubc.cs411.al.eval.trampoline;

import java.util.function.Supplier;

public interface Thunk extends Supplier<Trampoline> {
}
